# LifePath MVP

Android-first, no-backend prototype.

## Run
Open `index.html` in a browser or serve the folder from any static host.

## MVP
- 7 screens
- Wedding, pregnancy-preparation, astrology journeys
- Local deterministic scoring
- LocalStorage persistence
- Simulated ₹99 / ₹199 purchase flow
- Web Share API
- PWA manifest/service worker

## Before publishing
1. Replace demo checkout with a payment flow that complies with Google Play's billing/payment rules for digital goods.
2. Add a real privacy policy and data deletion mechanism.
3. Complete Google Play declarations, including health-related declarations if applicable.
4. Add proper app icons (512x512 and other required sizes).
5. Package as an Android App Bundle (.aab).
6. Test on multiple Android screen sizes.
