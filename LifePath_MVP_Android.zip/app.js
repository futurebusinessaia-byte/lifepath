const state={
  journey:null, qIndex:0, answers:{}, score:0, purchased:null
};
const questions={
 wedding:[
  {key:"date",title:"When is your wedding?",hint:"Pick a date, or tell us it's not decided yet.",type:"date"},
  {key:"guests",title:"How many guests are you expecting?",type:"options",options:["Under 100","100–250","250–500","500+"]},
  {key:"budget",title:"What's your approximate budget?",type:"options",options:["Under ₹2 lakh","₹2–5 lakh","₹5–10 lakh","₹10–25 lakh","₹25 lakh+"]},
  {key:"stage",title:"Where are you in the planning process?",type:"options",options:["Just starting","Venue searching","Vendors searching","Most things booked","Final preparations"]},
  {key:"focus",title:"What matters most right now?",type:"options",options:["Budget","Vendors","Guest management","Timeline","Everything"]}
 ],
 pregnancy:[
  {key:"stage",title:"What stage are you currently in?",type:"options",options:["Preparing for pregnancy","Pregnant","Preparing for hospital","Preparing for baby"]},
  {key:"deliveryMonth",title:"Expected month of delivery?",type:"month"},
  {key:"bag",title:"Have you started preparing your hospital bag?",type:"options",options:["Yes","Partly","Not yet"]},
  {key:"docs",title:"Are your important documents organized?",type:"options",options:["Yes","Partly","Not yet"]},
  {key:"focus",title:"What do you want help organizing?",type:"options",options:["Hospital bag","Baby essentials","Documents","Transport/contact plan","Everything"]}
 ],
 astrology:[
  {key:"dob",title:"What is your date of birth?",type:"date"},
  {key:"birthTime",title:"What is your birth time?",type:"time"},
  {key:"birthplace",title:"Where were you born?",hint:"City or town.",type:"text",placeholder:"e.g. Amritsar"},
  {key:"focus",title:"What are you interested in?",type:"options",options:["Marriage","Family","Career","Business","General traditional astrology"]},
  {key:"auspicious",title:"Do you want to explore auspicious-date information?",type:"options",options:["Yes","No"]}
 ]
};

function $(id){return document.getElementById(id)}
function showScreen(n,quick=false){
  document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));
  $("screen"+n).classList.add("active");
  $("resetBtn").classList.toggle("hidden",n===1);
  if(n===3) renderQuestion();
  if(n===4) renderResult();
  if(n===5) renderPlan();
  if(n===6 && quick) document.querySelector(".price-card").scrollIntoView({behavior:"smooth"});
  if(n===7) renderSaved();
  window.scrollTo({top:0,behavior:"smooth"});
}
function goHome(){showScreen(1)}
function resetApp(){
  if(confirm("Start over and clear this plan?")){
    localStorage.removeItem("lifepathState"); location.reload();
  }
}
function chooseJourney(j){
  state.journey=j; state.qIndex=0; state.answers={}; state.purchased=null;
  showScreen(3);
}
function renderQuestion(){
  const qs=questions[state.journey], q=qs[state.qIndex];
  $("stepLabel").textContent=`STEP 2 OF 4 • ${state.qIndex+1}/${qs.length}`;
  $("progressBar").style.width=((state.qIndex+1)/qs.length*100)+"%";
  $("questionTitle").textContent=q.title;
  $("questionHint").textContent=q.hint||"";
  const area=$("questionArea"); area.innerHTML="";
  if(q.type==="options"){
    const wrap=document.createElement("div"); wrap.className="option-list";
    q.options.forEach(opt=>{
      const b=document.createElement("button"); b.className="option"+(state.answers[q.key]===opt?" selected":"");
      b.textContent=opt; b.onclick=()=>{state.answers[q.key]=opt; renderQuestion()};
      wrap.appendChild(b);
    }); area.appendChild(wrap);
  }else{
    const field=document.createElement("div"); field.className="field";
    const input=document.createElement("input"); input.type=q.type==="month"?"month":q.type==="time"?"time":q.type==="date"?"date":"text";
    input.placeholder=q.placeholder||""; input.value=state.answers[q.key]||"";
    input.oninput=()=>state.answers[q.key]=input.value;
    field.appendChild(input); area.appendChild(field);
    if(q.type==="date" && q.key==="date"){
      const b=document.createElement("button"); b.className="secondary full"; b.textContent="Not decided yet";
      b.onclick=()=>{state.answers[q.key]="Not decided"; nextQuestion()}; area.appendChild(b);
    }
  }
}
function nextQuestion(){
  const q=questions[state.journey][state.qIndex];
  if(!state.answers[q.key]){toast("Please answer this question first.");return}
  if(state.qIndex<questions[state.journey].length-1){state.qIndex++;renderQuestion()}
  else {save();showScreen(4)}
}
function prevQuestion(){if(state.qIndex>0){state.qIndex--;renderQuestion()}else showScreen(2)}
function calcScore(){
  const a=state.answers;
  if(state.journey==="wedding"){
    let s={ "Just starting":30,"Venue searching":45,"Vendors searching":60,"Most things booked":80,"Final preparations":90}[a.stage]||30;
    if(a.guests) s+=a.guests==="500+"?2:4;
    if(a.budget) s+=4;
    if(a.focus==="Everything") s-=3;
    return Math.max(0,Math.min(100,s));
  }
  if(state.journey==="pregnancy"){
    let s=0;
    if(a.bag==="Yes")s+=20; else if(a.bag==="Partly")s+=10;
    if(a.docs==="Yes")s+=20; else if(a.docs==="Partly")s+=10;
    if(a.focus==="Everything")s+=20; else s+=10;
    if(a.stage==="Preparing for hospital")s+=20;
    if(a.stage==="Preparing for baby")s+=15;
    return Math.min(100,s);
  }
  return a.dob&&a.birthplace?75:55;
}
function journeyName(){return {wedding:"Wedding",pregnancy:"Baby Preparation",astrology:"Astrology"}[state.journey]}
function renderResult(){
  state.score=calcScore();
  const j=state.journey;
  $("resultTitle").textContent=j==="wedding"?"Your Wedding Readiness":j==="pregnancy"?"Your Preparation Status":"Your Personal Astro Plan";
  $("resultSubtitle").textContent=j==="wedding"?"A quick planning snapshot based on your answers.":j==="pregnancy"?"An organization snapshot—not a medical assessment.":"Traditional astrology-oriented planning based on the details you provided.";
  $("scoreValue").textContent=j==="astrology"?"★":state.score+"%";
  const body=$("resultBody");
  if(j==="wedding"){
    const tasks=["Confirm or review venue","Shortlist photographer","Confirm guest estimate","Review budget","Start invitations"];
    body.innerHTML=`<div class="result-card"><h3>Priority this week</h3>${tasks.slice(0,3).map((t,i)=>`<div class="task"><b>${i+1}</b><span>${t}</span></div>`).join("")}</div>
    <div class="result-card"><h3>Planning areas</h3><div class="status-grid">${["Venue","Guests","Photography","Makeup","Invitations","Transport"].map((x,i)=>`<div class="status"><span>${x}</span><strong>${i<Math.round(state.score/18)?"On track":"Needs attention"}</strong></div>`).join("")}</div></div>`;
  }else if(j==="pregnancy"){
    const missing=[];
    if(state.answers.bag!=="Yes")missing.push("Hospital bag");
    if(state.answers.docs!=="Yes")missing.push("Important documents");
    missing.push("Baby essentials","Transport/contact plan");
    body.innerHTML=`<div class="result-card"><h3>Still to organize</h3>${missing.slice(0,4).map(x=>`<div class="task"><b>☐</b><span>${x}</span></div>`).join("")}</div>
    <div class="notice">This app is for organization and preparation only. For medical questions, follow guidance from your qualified healthcare professional.</div>`;
  }else{
    body.innerHTML=`<div class="result-card"><h3>Your selected focus</h3><p>${state.answers.focus||"General traditional astrology"}</p></div>
    <div class="result-card"><h3>What you can explore</h3><div class="task"><b>✦</b><span>Traditional astrology information</span></div><div class="task"><b>✦</b><span>Compatibility information</span></div><div class="task"><b>✦</b><span>Auspicious-date planning information</span></div></div>
    <div class="notice">Astrology content is presented for traditional/cultural and entertainment purposes, not as scientific prediction or professional advice.</div>`;
  }
}
function renderPlan(){
  $("planTitle").textContent=`Your ${journeyName()} Plan`;
  const j=state.journey;
  const lists={
    wedding:["Review your guest estimate","Confirm key vendors","Check your budget","Update your wedding timeline","Prepare invitation list"],
    pregnancy:["Organize hospital bag","Gather important documents","Prepare baby essentials","Create a transport/contact plan","Save your preparation checklist"],
    astrology:["Review your selected focus","Explore traditional astrology information","Save any dates you want to research","Keep your birth details available","Review your personalized report"]
  };
  $("planBody").innerHTML=`<div class="result-card"><h3>This week</h3>${lists[j].map(x=>`<div class="task"><b>☐</b><span>${x}</span></div>`).join("")}</div>
  <div class="result-card"><h3>Your answers</h3>${Object.entries(state.answers).map(([k,v])=>`<div class="task"><b>•</b><span><strong>${pretty(k)}:</strong> ${v}</span></div>`).join("")}</div>`;
}
function pretty(k){return k.replace(/([A-Z])/g," $1").replace(/^./,s=>s.toUpperCase())}
function purchase(type){
  state.purchased=type; save();
  toast(type==="complete"?"Complete Plan unlocked in this demo.":"Quick Report unlocked in this demo.");
  setTimeout(()=>showScreen(7),700);
}
function renderSaved(){
  $("savedTitle").textContent=`Your ${journeyName()} Plan`;
  const product=state.purchased==="complete"?"Complete Plan":state.purchased==="quick"?"Quick Report":"Free Plan";
  const body=$("savedBody");
  body.innerHTML=`<div class="saved-section"><h3>✓ ${product}</h3><p>Your plan is saved on this device.</p></div>
  <div class="saved-section"><h3>Priority</h3><ul>${(state.journey==="wedding"?["Review vendors","Check budget","Update guest list"]:state.journey==="pregnancy"?["Hospital bag","Documents","Baby essentials"]:["Review your selected focus","Explore traditional information","Save planning dates"]).map(x=>`<li>${x}</li>`).join("")}</ul></div>
  <div class="saved-section"><h3>Journey</h3><p>${journeyName()} • Score ${state.journey==="astrology"?"Traditional focus":state.score+"%"}</p></div>`;
}
function shareText(){
  return `My LifePath ${journeyName()} plan is ready. ${state.journey==="astrology"?"Traditional astrology planning":"My preparation score is "+state.score+"%."}`;
}
async function shareResult(){
  const text=shareText();
  if(navigator.share){try{await navigator.share({title:"LifePath",text})}catch(e){}}
  else {await navigator.clipboard?.writeText(text);toast("Result copied to clipboard.");}
}
async function sharePlan(){
  const text=`LifePath — ${journeyName()} Plan\n\n${shareText()}\n\nCreated with LifePath.`;
  if(navigator.share){try{await navigator.share({title:"My LifePath Plan",text})}catch(e){}}
  else {await navigator.clipboard?.writeText(text);toast("Plan copied to clipboard.");}
}
function editAnswers(){state.qIndex=0;showScreen(3)}
function startAnother(){state.qIndex=0;state.answers={};state.purchased=null;showScreen(2)}
function save(){localStorage.setItem("lifepathState",JSON.stringify(state))}
function toast(msg){const t=$("toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2200)}
(function init(){
  try{const saved=JSON.parse(localStorage.getItem("lifepathState"));if(saved&&saved.journey){Object.assign(state,saved)}}catch(e){}
})();
